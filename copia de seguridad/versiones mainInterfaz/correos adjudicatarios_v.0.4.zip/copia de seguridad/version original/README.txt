Site=
-Problema=
 TecAfectada=
 Sectores=
-Problema=
 TecAfectada=
 Sectores=


JUSTIFICACIONES:
PUSCH
RSSI
SRVCC
Trafico5G
MIMORank2Bajo
SinMIMORank2
MIMORank4Bajo
SinMIMORank4